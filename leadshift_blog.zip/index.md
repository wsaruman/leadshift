---
layout: home
title: "Lead Shift"
---

Welcome to **Lead Shift** — insights and reflections on engineering leadership, change, and transformation.
