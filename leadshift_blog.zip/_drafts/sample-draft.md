---
layout: post
title: "Draft Example"
date: 2025-10-26
categories: engineering leadership
---

This is a draft post that will not be published until it's moved to _posts.
