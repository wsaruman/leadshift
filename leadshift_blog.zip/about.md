---
layout: page
title: About
---

**Lead Shift** shares lessons from leading and transforming engineering teams — focused on clarity, culture, and execution.
