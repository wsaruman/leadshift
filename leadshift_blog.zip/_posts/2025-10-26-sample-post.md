---
layout: post
title: "Sample Post"
date: 2025-10-26
categories: engineering leadership
---

This is a sample post for the Lead Shift blog.
